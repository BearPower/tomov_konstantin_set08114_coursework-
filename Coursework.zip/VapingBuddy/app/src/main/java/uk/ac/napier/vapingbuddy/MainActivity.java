package uk.ac.napier.vapingbuddy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.content.Context;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button Btn = findViewById(R.id.NewLiqBtn);
        Btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent NewLiq = new Intent(MainActivity.this,NewLiquid.class);
                startActivity (NewLiq);
            }
        });

        final TextView history=findViewById(R.id.HistoryList);

        int ch;
        String filename = "Liquids";
        StringBuffer inString = new StringBuffer("");
        FileInputStream inStream;
        try {
            inStream = getApplicationContext().openFileInput(filename);
            try {
                while ((ch = inStream.read()) != -1)
                    inString.append((char) ch);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            String data = new String(inString);
            history.setText(data);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    @Override
    protected void onStart()
    {
        final TextView history=findViewById(R.id.HistoryList);

        int ch;
        String filename = "Liquids";
        StringBuffer inString = new StringBuffer("");
        FileInputStream inStream;
        try {
            inStream = getApplicationContext().openFileInput(filename);
            try {
                while ((ch = inStream.read()) != -1)
                    inString.append((char) ch);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            String data = new String(inString);
            history.setText(data);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        super.onStart();
    }


    @Override
    protected void onResume()
    {
        final TextView history=findViewById(R.id.HistoryList);

        int ch;
        String filename = "Liquids";
        StringBuffer inString = new StringBuffer("");
        FileInputStream inStream;
        try {
            inStream = getApplicationContext().openFileInput(filename);
            try {
                while ((ch = inStream.read()) != -1)
                    inString.append((char) ch);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            String data = new String(inString);
            history.setText(data);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        super.onResume();
    }
}
