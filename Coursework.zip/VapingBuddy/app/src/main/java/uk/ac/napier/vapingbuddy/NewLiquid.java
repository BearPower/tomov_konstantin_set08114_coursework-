package uk.ac.napier.vapingbuddy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.content.Context;
import android.widget.Button;
import android.widget.Toast;
import java.lang.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NewLiquid extends AppCompatActivity {

    ImageView imgLiq;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_liquid);

        final EditText LiquidName=findViewById(R.id.NewLiquidName);
        final EditText LiquidCompany=findViewById(R.id.NewLiqComp);
        final EditText LiquidSize=findViewById(R.id.NewLiqSize);
        final EditText LiquidStrength=findViewById(R.id.NewLiqStr);

        Button AddNewLiqBtn = findViewById(R.id.NewLiqAdd);
        AddNewLiqBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                //validating the text on the E-liquid name

                String LiqNameString = LiquidName.getText().toString();

                if (LiqNameString.length()!=0 ){

                    boolean NameNotSpace = false;

                    for (int i=0;i<LiqNameString.length(); i++)
                    {
                        if(LiqNameString.charAt(i) != ' '){
                            NameNotSpace = true;
                            break;
                        }
                    }
                    if(NameNotSpace) {

                        //check if name company is not empty

                        String LiqCompanyString = LiquidCompany.getText().toString();


                        boolean CompanyNotSpase = false;

                        if(LiqCompanyString.length()!=0) {
                            for (int i=0;i<LiqCompanyString.length();i++){
                                if(LiqCompanyString.charAt(i)!=' '){
                                    CompanyNotSpase = true;
                                    break;
                                }
                            }
                            if(CompanyNotSpase) {

                                //cheking size


                                String LiqSizeString = LiquidSize.getText().toString();


                                if(LiqSizeString.length()!=0) {

                                    boolean SizeIsNumber = true;

                                    for (int i=0; i<LiqSizeString.length(); i++) {
                                        if (Character.isDigit(LiqSizeString.charAt(i))) {
                                        }else{
                                            SizeIsNumber = false;
                                            break;
                                        }
                                    }
                                    if (SizeIsNumber) {

                                        //check liquid strength


                                        String LiqStrString = LiquidStrength.getText().toString();


                                        if(LiqStrString.length()!=0) {

                                            boolean StrentIsNumber = true;

                                            for(int i=0; i < LiqStrString.length();i++){
                                                if(!(Character.isDigit(LiqStrString.charAt(i)))){
                                                    StrentIsNumber=false;
                                                    break;
                                                }
                                            }

                                            if(StrentIsNumber) {
                                                if(Integer.parseInt(LiqStrString)<=24 && (Integer.parseInt(LiqStrString))>=0) {

                                                    //Adding the Information to the internal file
                                                    String filename = "Liquids";
                                                    String outString = LiqNameString+" from "+LiqCompanyString+". Size of "+LiqSizeString+"ml with strength of "+LiqStrString+"% Nic ,started on "+android.text.format.DateFormat.format("yyyy-MM-dd", new java.util.Date())+"\n";
                                                    FileOutputStream outSteam;

                                                    try {
                                                        outSteam = getApplicationContext().openFileOutput(filename, Context.MODE_APPEND);
                                                        outSteam.write(outString.getBytes());
                                                        outSteam.close();
                                                        Toast.makeText(getBaseContext(),"The Liquid has been added to you're history.", Toast.LENGTH_LONG).show();
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                    }
                                                    //Creating the mill file in case of not existing

                                                    String MillFile = "Mill";
                                                    FileOutputStream outMill;

                                                    try {
                                                        outMill = getApplicationContext().openFileOutput(MillFile, Context.MODE_APPEND);
                                                        outMill.write('0');
                                                        outMill.close();
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                    }
                                                    //open the mill file
/*
                                                   int chMill;
                                                    StringBuffer OldMill = new StringBuffer("");
                                                    FileInputStream inOldMill;
                                                    try {
                                                        inOldMill = getApplicationContext().openFileInput(MillFile);
                                                        try {
                                                            while ((chMill = inOldMill.read()) != -1)
                                                                OldMill.append((char) chMill);
                                                        } catch (IOException e) {
                                                            e.printStackTrace();
                                                        } catch (Exception e) {
                                                            e.printStackTrace();
                                                        }
                                                        String oldMill = new String(OldMill);
                                                        int TotalMillI = ((new Integer(oldMill)+new Integer(LiqSizeString)))/10;
                                                        String TotalMill = Integer.toString(TotalMillI);

                                                        //Writing the total to the file

                                                        FileOutputStream outTotalMill;

                                                        try {
                                                            outTotalMill = getApplicationContext().openFileOutput(MillFile, Context.MODE_PRIVATE);
                                                            outTotalMill.write(TotalMill.getBytes());
                                                            outTotalMill.close();
                                                        } catch (Exception e) {
                                                            e.printStackTrace();
                                                        }

                                                        Toast.makeText(getBaseContext(), TotalMill, Toast.LENGTH_LONG).show();

                                                    } catch (FileNotFoundException e) {
                                                        e.printStackTrace();
                                                    }

*/
                                                }else{
                                                    Toast.makeText(getBaseContext(), "The Strength must be from 0 to 24 %", Toast.LENGTH_LONG).show();
                                                }
                                            }else{
                                                Toast.makeText(getBaseContext(), "The Liquid Strength must be positive a number", Toast.LENGTH_LONG).show();
                                            }
                                        }else{
                                            Toast.makeText(getBaseContext(), "Please enter the strength of the liquid", Toast.LENGTH_LONG).show();
                                        }
                                    } else {
                                        Toast.makeText(getBaseContext(), "The Size must be posotive number", Toast.LENGTH_LONG).show();
                                    }
                                }else{
                                    Toast.makeText(getBaseContext(), "Please enter the size of the liquid", Toast.LENGTH_LONG).show();
                                }
                            }else{
                                Toast.makeText(getBaseContext(), "Please enter company making the liquid", Toast.LENGTH_LONG).show();
                            }
                        }else{
                            Toast.makeText(getBaseContext(), "Please enter company making the liquid", Toast.LENGTH_LONG).show();
                        }
                    }else{
                        Toast.makeText(getBaseContext(), "Please enter name of the liquid", Toast.LENGTH_LONG).show();

                    }
                }else{
                    Toast.makeText(getBaseContext(), "Please enter name of the liquid", Toast.LENGTH_LONG).show();
                }
        }
        });


        imgLiq = findViewById(R.id.NewLiqPic);
        imgLiq.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, 0);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null)
        {
            Bitmap bp = (Bitmap) data.getExtras().get("data");
            imgLiq.setImageBitmap(bp);
        }

    }
}
